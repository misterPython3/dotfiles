return {
    init_options = {
	hostInfo = "neovim",
	maxTsServerMemory = 384,
	tsserver = {
	    maxTsServerMemory = 496
	}
    }
}

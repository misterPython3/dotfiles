return {
    settings = {
	execArgv = {"--max-semi-space-size=496", "--max-old-space-size=496"},
	["eslint.execArgv"] = {"--max-semi-space-size=496", "--max-old-space-size=496"}
    }
}

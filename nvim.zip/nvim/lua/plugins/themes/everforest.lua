return {
    "neanias/everforest-nvim",
    version = false,
    config = function()
	require("everforest").setup({
	    -- Your config here
	})
    end,
}

return {
    "vague2k/vague.nvim",
    opts = {}
}

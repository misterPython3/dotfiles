return {
    "navarasu/onedark.nvim",
    opts = {
	style = "cool"
    }
}

return {
	"EdenEast/nightfox.nvim"
}

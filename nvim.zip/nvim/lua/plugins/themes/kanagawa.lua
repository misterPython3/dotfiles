return {
    "rebelot/kanagawa.nvim"
}

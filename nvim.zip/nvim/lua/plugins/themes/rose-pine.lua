return {
	"rose-pine/neovim",
	name = "rose-pine",
}

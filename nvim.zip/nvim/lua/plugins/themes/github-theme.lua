return {
    'projekt0n/github-nvim-theme',
    name = 'github-theme'
}

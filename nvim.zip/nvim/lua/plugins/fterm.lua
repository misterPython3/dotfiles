return {
    "numToStr/FTerm.nvim",
    opts = {
	border = "rounded",
	dimensions = {
	    height = 0.64,
	    width = 0.64,
	},
    }
}

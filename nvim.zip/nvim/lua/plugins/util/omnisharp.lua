return {
    'OmniSharp/omnisharp-vim'
}
